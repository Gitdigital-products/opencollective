/**
 * Constants for the KYC Compliance SDK
 */

import { PublicKey } from '@solana/web3.js';

/**
 * Program ID for the KYC Compliance program
 */
export const KYC_COMPLIANCE_PROGRAM_ID = new PublicKey(
  'KYCCom5KiZAyWvt1m1c9wL8rJ9jB8x7Z3vT4qN2wX6y'
);

/**
 * Seed constants for PDA derivation
 */
export const SEEDS = {
  REGISTRY: Buffer.from('registry'),
  IDENTITY: Buffer.from('identity'),
  MINT_METADATA: Buffer.from('mint_metadata'),
  COMPLIANCE_LEVEL: Buffer.from('compliance_level'),
  EXTRA_ACCOUNT_META: Buffer.from('extra_account_meta'),
} as const;

/**
 * Maximum values
 */
export const MAX_VALUES = {
  COUNTRY_CODE_LENGTH: 2,
  COMPLIANCE_HASH_LENGTH: 32,
  METADATA_URI_LENGTH: 200,
  MAX_COMPLIANCE_LEVELS: 10,
  MAX_TRANSFER_AMOUNT: 1_000_000_000,
} as const;

/**
 * Default values
 */
export const DEFAULTS = {
  COMPLIANCE_LEVEL: 1,
  MAX_TRANSFER_AMOUNT: Number.MAX_SAFE_INTEGER,
} as const;

/**
 * Restricted country codes (ISO 3166-1 alpha-2)
 */
export const RESTRICTED_COUNTRIES = [
  'CU', // Cuba
  'IR', // Iran
  'KP', // North Korea
  'SY', // Syria
  'RU', // Russia
  'BY', // Belarus
] as const;

/**
 * Token extension types
 */
export const TOKEN_EXTENSIONS = {
  TRANSFER_HOOK: 1 << 0,
  PERMANENT_DELEGATE: 1 << 1,
  METADATA_POINTER: 1 << 2,
} as const;

/**
 * Account sizes
 */
export const ACCOUNT_SIZES = {
  REGISTRY: 32 + 1 + 1 + 1 + 8 + 1 + 1 + 1000 + 1 + 256, // Approximate
  IDENTITY: 32 + 32 + 32 + 8 + 1 + 2 + 1 + 1 + 1 + 1 + 8 + 8 + 512 + 1 + 256, // Approximate
  MINT_COMPLIANCE: 32 + 32 + 1 + 1 + 1 + 128,
  EXTRA_ACCOUNT_META: 32 + 32 + 1 + 1 + 128,
} as const;
