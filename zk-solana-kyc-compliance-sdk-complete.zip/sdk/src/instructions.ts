/**
 * Instruction builders for the KYC Compliance SDK
 */

import {
  Connection,
  PublicKey,
  SystemProgram,
  TransactionInstruction,
} from '@solana/web3.js';
import { getAssociatedTokenAddress, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { KYC_COMPLIANCE_PROGRAM_ID, SEEDS } from './constants';
import type {
  InitializeRegistryArgs,
  UpdateRegistryArgs,
  RegisterIdentityArgs,
  UpdateIdentityArgs,
  ConfigureMintArgs,
  SetComplianceLevelArgs,
} from './types';

/**
 * Finds the registry PDA
 */
export function findRegistryAddress(): PublicKey {
  const [address] = PublicKey.findProgramAddressSync(
    [SEEDS.REGISTRY],
    KYC_COMPLIANCE_PROGRAM_ID
  );
  return address;
}

/**
 * Finds an identity PDA
 */
export function findIdentityAddress(registry: PublicKey, owner: PublicKey): PublicKey {
  const [address] = PublicKey.findProgramAddressSync(
    [SEEDS.IDENTITY, registry.toBytes(), owner.toBytes()],
    KYC_COMPLIANCE_PROGRAM_ID
  );
  return address;
}

/**
 * Finds a mint compliance PDA
 */
export function findMintComplianceAddress(mint: PublicKey): PublicKey {
  const [address] = PublicKey.findProgramAddressSync(
    [SEEDS.MINT_METADATA, mint.toBytes()],
    KYC_COMPLIANCE_PROGRAM_ID
  );
  return address;
}

/**
 * Finds a compliance level PDA
 */
export function findComplianceLevelAddress(level: number): PublicKey {
  const [address] = PublicKey.findProgramAddressSync(
    [SEEDS.COMPLIANCE_LEVEL, Buffer.from([level])],
    KYC_COMPLIANCE_PROGRAM_ID
  );
  return address;
}

/**
 * Finds an extra account meta PDA
 */
export function findExtraAccountMetaAddress(mint: PublicKey): PublicKey {
  const [address] = PublicKey.findProgramAddressSync(
    [SEEDS.EXTRA_ACCOUNT_META, mint.toBytes()],
    KYC_COMPLIANCE_PROGRAM_ID
  );
  return address;
}

/**
 * Creates the initialize registry instruction
 */
export async function initializeRegistry(
  args: InitializeRegistryArgs,
  payer: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();

  const data = Buffer.alloc(4 + 4 + 1 + 1 + 4 + args.restrictedCountries.length * 2);
  let offset = 0;

  // Instruction discriminator (0)
  data.writeUInt32LE(0, offset);
  offset += 4;

  // required_compliance_level
  data.writeUInt8(args.requiredComplianceLevel, offset);
  offset += 1;

  // require_both_verified
  data.writeUInt8(args.requireBothVerified ? 1 : 0, offset);
  offset += 1;

  // allow_self_transfer
  data.writeUInt8(args.allowSelfTransfer ? 1 : 0);
  offset += 1;

  // restricted_countries
  data.writeUInt32LE(args.restrictedCountries.length, offset);
  offset += 4;

  for (const country of args.restrictedCountries) {
    const code = country.substring(0, 2).toUpperCase();
    data.write(code.charCodeAt(0), offset);
    data.write(code.charCodeAt(1), offset + 1);
    offset += 2;
  }

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: payer, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: registry, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the update registry instruction
 */
export async function updateRegistry(
  args: UpdateRegistryArgs,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();

  // Build the data buffer with proper encoding
  const hasRequired = args.requiredComplianceLevel !== undefined;
  const hasRequireBoth = args.requireBothVerified !== undefined;
  const hasAllowSelf = args.allowSelfTransfer !== undefined;
  const hasCountries = args.restrictedCountries !== undefined;

  const countriesLength = args.restrictedCountries?.length ?? 0;
  const dataSize = 4 + 1 + 1 + 1 + 1 + 4 + countriesLength * 2 + 1 + 1 + 1 + 1;
  const data = Buffer.alloc(dataSize);
  let offset = 0;

  // Instruction discriminator (1)
  data.writeUInt32LE(1, offset);
  offset += 4;

  // required_compliance_level: Option<u8>
  data.writeUInt8(hasRequired ? 1 : 0, offset);
  offset += 1;
  if (hasRequired) {
    data.writeUInt8(args.requiredComplianceLevel!, offset);
  }
  offset += 1;

  // require_both_verified: Option<bool>
  data.writeUInt8(hasRequireBoth ? 1 : 0, offset);
  offset += 1;
  if (hasRequireBoth) {
    data.writeUInt8(args.requireBothVerified! ? 1 : 0, offset);
  }
  offset += 1;

  // allow_self_transfer: Option<bool>
  data.writeUInt8(hasAllowSelf ? 1 : 0, offset);
  offset += 1;
  if (hasAllowSelf) {
    data.writeUInt8(args.allowSelfTransfer! ? 1 : 0, offset);
  }
  offset += 1;

  // restricted_countries: Option<Vec<[u8; 2]>>
  data.writeUInt8(hasCountries ? 1 : 0, offset);
  offset += 1;
  if (hasCountries) {
    data.writeUInt32LE(countriesLength, offset);
    offset += 4;
    for (const country of args.restrictedCountries!) {
      const code = country.substring(0, 2).toUpperCase();
      data.write(code.charCodeAt(0), offset);
      data.write(code.charCodeAt(1), offset + 1);
      offset += 2;
    }
  }

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the set registry pause instruction
 */
export async function setRegistryPause(
  paused: boolean,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();

  const data = Buffer.alloc(4 + 1);
  data.writeUInt32LE(2, 0); // Instruction discriminator
  data.writeUInt8(paused ? 1 : 0, 4);

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the set delegate instruction
 */
export async function setDelegate(
  delegate: PublicKey | null,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();

  const data = Buffer.alloc(4 + 1 + 32);
  let offset = 0;

  data.writeUInt32LE(3, offset); // Instruction discriminator
  offset += 1;

  data.writeUInt8(delegate ? 1 : 0, offset);
  offset += 1;

  if (delegate) {
    delegate.toBuffer().copy(data, offset);
  }

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the configure mint instruction
 */
export async function configureMint(
  args: ConfigureMintArgs,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const mintCompliance = findMintComplianceAddress(args.mint);

  const data = Buffer.alloc(4 + 1);
  data.writeUInt32LE(4, 0); // Instruction discriminator
  data.writeUInt8(args.requiredComplianceLevel, 4);

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: mintCompliance, isSigner: false, isWritable: true },
      { pubkey: args.mint, isSigner: false, isWritable: false },
    ],
    data,
  });
}

/**
 * Creates the register identity instruction
 */
export async function registerIdentity(
  args: RegisterIdentityArgs,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, args.owner);

  const data = Buffer.alloc(4 + 32 + 32 + 8 + 1 + 2);
  let offset = 0;

  // Instruction discriminator (5)
  data.writeUInt32LE(5, offset);
  offset += 4;

  // owner
  args.owner.toBuffer().copy(data, offset);
  offset += 32;

  // compliance_hash
  args.complianceHash.copy(data, offset);
  offset += 32;

  // expiry
  data.writeBigInt64LE(BigInt(args.expiry), offset);
  offset += 8;

  // compliance_level
  data.writeUInt8(args.complianceLevel, offset);
  offset += 1;

  // country_code
  const code = args.countryCode.substring(0, 2).toUpperCase();
  data.write(code.charCodeAt(0), offset);
  data.write(code.charCodeAt(1), offset + 1);

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the update identity instruction
 */
export async function updateIdentity(
  owner: PublicKey,
  args: UpdateIdentityArgs,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, owner);

  const hasExpiry = args.expiry !== undefined;
  const hasLevel = args.complianceLevel !== undefined;
  const hasCountry = args.countryCode !== undefined;
  const hasMetadata = args.metadata !== undefined;

  // Calculate buffer size
  let size = 4 + 1 + 1 + 1 + 1; // discriminator + option flags
  if (hasExpiry) size += 8;
  if (hasLevel) size += 1;
  if (hasCountry) size += 2;
  if (hasMetadata) size += 4 + (args.metadata?.length ?? 0);

  const data = Buffer.alloc(size);
  let offset = 0;

  // Instruction discriminator (6)
  data.writeUInt32LE(6, offset);
  offset += 4;

  // expiry: Option<i64>
  data.writeUInt8(hasExpiry ? 1 : 0, offset);
  offset += 1;
  if (hasExpiry) {
    data.writeBigInt64LE(BigInt(args.expiry!), offset);
    offset += 8;
  }

  // compliance_level: Option<u8>
  data.writeUInt8(hasLevel ? 1 : 0, offset);
  offset += 1;
  if (hasLevel) {
    data.writeUInt8(args.complianceLevel!, offset);
    offset += 1;
  }

  // country_code: Option<[u8; 2]>
  data.writeUInt8(hasCountry ? 1 : 0, offset);
  offset += 1;
  if (hasCountry) {
    const code = args.countryCode!.substring(0, 2).toUpperCase();
    data.write(code.charCodeAt(0), offset);
    data.write(code.charCodeAt(1), offset + 1);
    offset += 2;
  }

  // metadata: Option<Vec<u8>>
  data.writeUInt8(hasMetadata ? 1 : 0, offset);
  offset += 1;
  if (hasMetadata) {
    data.writeUInt32LE(args.metadata!.length, offset);
    offset += 4;
    args.metadata!.copy(data, offset);
  }

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the freeze identity instruction
 */
export async function freezeIdentity(
  owner: PublicKey,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, owner);

  const data = Buffer.alloc(4);
  data.writeUInt32LE(7, 0); // Instruction discriminator

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the unfreeze identity instruction
 */
export async function unfreezeIdentity(
  owner: PublicKey,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, owner);

  const data = Buffer.alloc(4);
  data.writeUInt32LE(8, 0); // Instruction discriminator

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the revoke identity instruction
 */
export async function revokeIdentity(
  owner: PublicKey,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, owner);

  const data = Buffer.alloc(4);
  data.writeUInt32LE(9, 0); // Instruction discriminator

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the verify AML instruction
 */
export async function verifyAml(
  owner: PublicKey,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const identity = findIdentityAddress(registry, owner);

  const data = Buffer.alloc(4);
  data.writeUInt32LE(10, 0); // Instruction discriminator

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: identity, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the initialize extra account meta instruction
 */
export async function initializeExtraAccountMeta(
  mint: PublicKey,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();
  const extraAccountMeta = findExtraAccountMetaAddress(mint);

  const data = Buffer.alloc(4 + 32);
  data.writeUInt32LE(12, 0); // Instruction discriminator
  mint.toBuffer().copy(data, 4);

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
      { pubkey: registry, isSigner: false, isWritable: false },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: extraAccountMeta, isSigner: false, isWritable: true },
    ],
    data,
  });
}

/**
 * Creates the update max transfer instruction
 */
export async function updateMaxTransfer(
  maxAmount: number,
  authority: PublicKey
): Promise<TransactionInstruction> {
  const registry = findRegistryAddress();

  const data = Buffer.alloc(4 + 8);
  data.writeUInt32LE(4, 0); // Instruction discriminator
  data.writeBigInt64LE(BigInt(maxAmount), 4);

  return new TransactionInstruction({
    programId: KYC_COMPLIANCE_PROGRAM_ID,
    keys: [
      { pubkey: authority, isSigner: true, isWritable: true },
      { pubkey: registry, isSigner: false, isWritable: true },
    ],
    data,
  });
}
