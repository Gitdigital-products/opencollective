
import { Program, AnchorProvider, Idl } from "@coral-xyz/anchor";
import { PublicKey } from "@solana/web3.js";

export class KycClient {
  program: Program;

  constructor(provider: AnchorProvider, idl: Idl, programId: PublicKey) {
    this.program = new Program(idl, programId, provider);
  }

  async getRegistry(registry: PublicKey) {
    return await this.program.account.registry.fetch(registry);
  }
}
