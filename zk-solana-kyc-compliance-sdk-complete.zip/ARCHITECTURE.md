
# zk-solana-kyc-compliance-sdk Architecture

- Anchor-based on-chain compliance registry
- TypeScript SDK wrapper
- Future Transfer Hook integration
- Off-chain daemon indexing (optional)
