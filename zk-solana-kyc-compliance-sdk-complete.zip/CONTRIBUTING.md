# Contributing to ZK-Solana KYC Compliance SDK

Thank you for your interest in contributing to the ZK-Solana KYC Compliance SDK. This document provides guidelines and best practices for contributing to this project.

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [Getting Started](#getting-started)
3. [Development Environment](#development-environment)
4. [Making Changes](#making-changes)
5. [Pull Request Process](#pull-request-process)
6. [Coding Standards](#coding-standards)
7. [Testing](#testing)
8. [Documentation](#documentation)
9. [Commit Messages](#commit-messages)

## Code of Conduct

By participating in this project, you are expected to uphold our [Code of Conduct](CODEOFCONDUCT.md). Please report unacceptable behavior to the project maintainers.

## Getting Started

### Prerequisites

Before contributing, ensure you have the following installed:

- **Rust** (1.70 or later) - For the on-chain program
- **Node.js** (18.x or later) - For the TypeScript SDK
- **Anchor** (0.30.x or later) - For building Solana programs
- **Solana CLI** (1.18.x or later) - For local development
- **Yarn** - For package management

### Repository Structure

```
zk-solana-kyc-compliance-sdk/
├── programs/           # Solana programs (Rust)
│   └── kyc-compliance/
├── sdk/               # TypeScript SDK
│   └── src/
├── tests/             # Integration tests
├── docs/              # Documentation
├── daemon/            # Off-chain verification daemon
└── crates/            # Rust utility crates
```

## Development Environment

### Setting Up Local Validator

1. Start a local Solana validator with Token-2022 extensions:

```bash
solana-test-validator --url devnet --bpf-program <PROGRAM_ID> programs/kyc-compliance/target/deploy/kyc_compliance.so
```

2. Configure your environment:

```bash
cp .env.example .env
# Edit .env with your configuration
```

3. Build the program:

```bash
anchor build
```

4. Run tests:

```bash
# Rust tests
cargo test

# TypeScript SDK tests
cd sdk && yarn test

# Integration tests
anchor test
```

## Making Changes

### Branch Naming

Create feature branches from `main`:

- `feature/description` - New features
- `fix/description` - Bug fixes
- `refactor/description` - Code refactoring
- `docs/description` - Documentation updates
- `test/description` - Adding or fixing tests

### Workflow

1. Fork the repository
2. Create a feature branch from `main`
3. Make your changes
4. Add tests for new functionality
5. Update documentation as needed
6. Push to your fork and submit a pull request

## Pull Request Process

### Before Submitting

1. **Run all tests** to ensure nothing is broken:
   ```bash
   cargo test
   cd sdk && yarn test
   anchor test
   ```

2. **Run linters**:
   ```bash
   cargo fmt -- --check
   cargo clippy -- -D warnings
   cd sdk && yarn lint
   ```

3. **Update changelog** if applicable (CHANGELOG.md)

### Pull Request Template

```markdown
## Description
[Description of the changes]

## Type of Change
- [ ] Bug fix (non-breaking change)
- [ ] New feature (non-breaking change)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work)
- [ ] Documentation update

## Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Tested manually in local validator

## Checklist
- [ ] My code follows the style guidelines
- [ ] I have performed a self-review of my code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
```

## Coding Standards

### Rust (On-Chain Program)

- Follow the [Rust Style Guide](https://doc.rust-lang.org/beta/style-guide/)
- Use `cargo fmt` for formatting
- Use `cargo clippy` for linting
- Write doc comments for public functions
- Use meaningful variable and function names
- Keep functions focused and small

### TypeScript (SDK)

- Follow the [Airbnb JavaScript Style Guide](https://github.com/airbnb/javascript)
- Use ESLint and Prettier
- Write JSDoc comments for public APIs
- Use meaningful variable names
- Keep functions focused and small
- Use TypeScript strict mode

### General

- Write meaningful commit messages
- Keep changes focused and atomic
- Don't introduce unnecessary dependencies
- Consider security implications

## Testing

### Unit Tests

Rust:
```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_some_function() {
        // Test implementation
    }
}
```

TypeScript:
```typescript
describe('SomeModule', () => {
  it('should do something', () => {
    // Test implementation
  });
});
```

### Integration Tests

Integration tests are located in `tests/` and use the Anchor test framework.

```typescript
import * as anchor from '@project-serum/anchor';

describe('kyc-compliance', () => {
  // Test implementation
});
```

### Test Coverage

Aim for high test coverage:
- On-chain program: 80%+ coverage
- SDK: 80%+ coverage
- All public APIs should have tests

## Documentation

### Code Documentation

- Document all public APIs with JSDoc/Rustdoc
- Include usage examples where helpful
- Explain complex logic with comments

### README

Keep the README up to date with:
- Installation instructions
- Quick start guide
- API reference links
- Examples

### API Documentation

Generate API documentation:
```bash
# Rust
cargo doc --no-deps

# TypeScript
cd sdk && yarn docs
```

## Commit Messages

Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance

### Example

```
feat(registry): add support for compliance levels

Add compliance levels (1-10) to allow tiered verification.
Each level can have different requirements and transfer limits.

Closes #123
```

## Questions?

If you have questions, please open an issue or reach out to the maintainers.

Thank you for contributing!
