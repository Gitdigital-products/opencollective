
use anchor_lang::prelude::*;

declare_id!("Kyc111111111111111111111111111111111111111");

#[program]
pub mod kyc_compliance {
    use super::*;

    pub fn initialize_registry(ctx: Context<InitializeRegistry>) -> Result<()> {
        let registry = &mut ctx.accounts.registry;
        registry.authority = ctx.accounts.authority.key();
        registry.verified = false;
        registry.compliance_level = 0;
        registry.expires_at = 0;
        Ok(())
    }

    pub fn verify_user(ctx: Context<VerifyUser>, level: u8, expires_at: i64) -> Result<()> {
        let registry = &mut ctx.accounts.registry;
        registry.verified = true;
        registry.compliance_level = level;
        registry.expires_at = expires_at;
        Ok(())
    }

    pub fn revoke_user(ctx: Context<RevokeUser>) -> Result<()> {
        let registry = &mut ctx.accounts.registry;
        registry.verified = false;
        Ok(())
    }
}

#[account]
pub struct Registry {
    pub authority: Pubkey,
    pub compliance_level: u8,
    pub verified: bool,
    pub expires_at: i64,
}

#[derive(Accounts)]
pub struct InitializeRegistry<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 1 + 1 + 8)]
    pub registry: Account<'info, Registry>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct VerifyUser<'info> {
    #[account(mut)]
    pub registry: Account<'info, Registry>,
    pub authority: Signer<'info>,
}

#[derive(Accounts)]
pub struct RevokeUser<'info> {
    #[account(mut)]
    pub registry: Account<'info, Registry>,
    pub authority: Signer<'info>,
}
