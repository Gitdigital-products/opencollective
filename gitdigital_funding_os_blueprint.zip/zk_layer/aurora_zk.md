
# Aurora ZK Layer

## Proven
- donation occurred
- milestone funding threshold reached
- payout authorization

## Hidden
- donor identity
- internal treasury allocation

## Circuits
- DonationProof
- ThresholdProof
- BadgeEligibility
- TreasuryProof
