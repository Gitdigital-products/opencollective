
# Notion Integration

Databases

Milestones
Funding Events
Badges
Grants
Agents

Notion webhooks propagate updates to Funding OS.
