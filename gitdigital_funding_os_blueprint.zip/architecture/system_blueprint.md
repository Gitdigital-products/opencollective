
# System Blueprint

## Core Architecture

Public Dashboard
    |
Funding Core
    |
-----------------------------------------------------
| OpenCollective | Solana | Aurora ZK | Badge Auth |
-----------------------------------------------------
                |
             Railway
                |
-----------------------------------------------------
| Tinkerflow Agents | OpenClaw | Notion | GitHub |
-----------------------------------------------------

## Event Flow

1. Funding event
2. Treasury sync
3. Unified meter update
4. ZK proof generation
5. Badge evaluation
6. Milestone unlock
7. Dashboard update
