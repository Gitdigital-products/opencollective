
# Data Flow Specification

Funding Event -> Treasury Sync Engine -> Unified Meter Engine
-> Aurora ZK Proof Generator -> Badge Authority
-> GitHub Milestone Registry -> Public Dashboard
