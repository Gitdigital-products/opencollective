
# GitHub Project #9 Mapping

Milestones are stored in GitHub Projects.

Example:

Core OS
Funding Requirement: $10,000
Badge Required: Builder

Agent monitors project progress and syncs with Funding OS.
