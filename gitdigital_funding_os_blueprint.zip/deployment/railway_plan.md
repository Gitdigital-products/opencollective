
# Railway Deployment

Services

- funding-api
- badge-api
- proof-service
- treasury-sync
- agent-gateway
- dashboard

Environment Variables

OPEN_COLLECTIVE_API
SOLANA_RPC
AURORA_PROVER_KEY
GITHUB_TOKEN
NOTION_TOKEN
