
# Agent Execution Layer

Agents

Treasury Agent
Proof Agent
Milestone Agent
Governance Agent

Agents interact through Funding API and require badge authorization.
