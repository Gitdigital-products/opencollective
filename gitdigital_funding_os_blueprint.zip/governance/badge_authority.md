
# Badge Authority

Badge Schema

{
 id,
 name,
 level,
 permissions,
 proof_reference,
 issuer,
 timestamp
}

## Example Permissions

Contributor -> voting
Builder -> milestone execution
Governor -> governance changes
