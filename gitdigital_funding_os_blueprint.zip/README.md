
# GitDigital Funding OS

Unified badge-governed, multi-chain funding and governance engine.

## Components
- Open Collective (USD treasury)
- Solana (SOL + USDC treasury)
- Aurora ZK proof layer
- Railway runtime
- Badge Authority governance
- GitHub Project Board milestone registry
- Tinkerflow AI agent execution
- OpenClaw messaging gateway
- Notion operational knowledge graph

This repository contains the architecture, protocol specifications, and deployment blueprint.
