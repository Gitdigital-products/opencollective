
# Treasury Logic

Unified Funding Units (FU)

FU = USD equivalent

TotalFunding = USD + SOL_value + USDC

Thresholds trigger:
- milestone unlocks
- badge issuance
- treasury payouts
